#include <iostream>

#include "Zadanie2.h"
#include "Zadanie3.h"

using namespace std;

#include "Zadanie1.h"
#include "Zadanie2.h"
#include "Zadanie3.h"

int main() {
    cout << SumaLiczb(6, 4)<<endl;
    witaj();
    cout << endl;
    cout << SumaDoN(10)<<endl;
    zadanie3();
    return 0;

}