//
// Created by Student on 9.11.2025.
//

#ifndef LAB2_ZADANIE2_H
#define LAB2_ZADANIE2_H

int SumaDoN(int n);

#endif //LAB2_ZADANIE2_H