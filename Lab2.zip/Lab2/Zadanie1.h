#ifndef Lab2_Zadanie1_H
#define Lab2_Zadanie1_H

int SumaLiczb(int liczba1, int liczba2);
void witaj();


#endif