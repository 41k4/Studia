//
// Created by Student on 9.11.2025.
//

#ifndef LAB2_ZADANIE3_H
#define LAB2_ZADANIE3_H

int zadanie3();

#endif //LAB2_ZADANIE3_H