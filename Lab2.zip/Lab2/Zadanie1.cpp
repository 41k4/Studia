#include "Zadanie1.h"
#include <iostream>
using namespace std;

int SumaLiczb(int liczba1, int liczba2) {
    int suma;
    suma = liczba1 + liczba2;
    return suma;
}

void witaj() {
    cout << "Witaj";

}