#include "Zadanie3.h"
#include <iostream>
using namespace std;

int zadanie3() {
    int liczba;

    while (true) {
        cout << "POdaj liczbe, jezeli podaszs 0 program zakonczy swoje dzialanie :D";
        cin >> liczba;

        if (liczba == 0) {
            cout << "Kooooniec!";
            break;
        }

        if (liczba <= 0) {
            cout << "Liczba jest mniejsza od 0, sprobuj ponownie C:";
            continue;
        }
        cout << "Twoja liczba jest:" << liczba << endl;
    }
}