#include <iostream>
using namespace std ;
/* ---------plik labolatorium 1.2 (labolatorium 1) ------------*/

// int main () {
//     cout << " Hello world " << endl ; // komentarz
//
//     return 0;
// } //zadanie 1

// int main()
// {
//     // wstawienieb trzech znaków enter
//     cout<<"Ala ma kota\n\na kot ma Ale :)\n";
//     cout<<"Ala ma kota"<<endl<<endl<<"a kot ma Ale :)"<<endl;
//
//     return 0;
//
// } //zadanie 2

// int main ()
// {
//     cout << "Czy ten program\n";
//     cout << "wypisze dane\n";
//     cout << "w trzech linijkach \n";
//     return 0;
//
// } // zadanie 3

/* ----------plik labolatorium 1.1 (labolatorium 2) -------------*/

// int main()
// {
//     //wyswietla pojemnosc zmiennej
//     cout << sizeof(short) << endl;
//     cout << sizeof(int) << endl;
//     cout << sizeof(long) << endl;
//     cout << sizeof(long long ) << endl;
//     return 0;
// } //zadanie 1

// zmienna globalna
int globalna = 5;

void pokazZmienna()
{
    // zmienna lokalna
    int lokalna = 10;
    cout << "Wartosc zmiennej lokalnej " << lokalna << endl;
    cout << "Wartosc zmiennej globalne" << globalna << endl;
}

int main()
{
    cout << "Wartosc zmiennej globalnej" << globalna << endl;
    pokazZmienna();
    globalna++;
    cout << "Wartosc zmiennej globalnej" << globalna << endl;
    return 0;
    } // zadanie 2