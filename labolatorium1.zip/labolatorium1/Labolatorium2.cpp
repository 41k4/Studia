 zadanie z pliku labolatorium 1.1
zadanie 1
operatory

#include <iostream>
